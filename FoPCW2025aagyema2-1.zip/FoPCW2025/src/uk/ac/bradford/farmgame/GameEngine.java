package uk.ac.bradford.farmgame;

import java.util.Random;
import uk.ac.bradford.farmgame.Tile.TileType;

/**
 * The GameEngine class is responsible for managing information about the game,
 * creating the level, the player and pest, as well as updating information when
 * a key is pressed (processed by the InputHandler) while the game is running.
 *
 * @author prtrundl
 */
public class GameEngine {

    /**
     * The width of the level, measured in tiles. Changing this may cause the
     * display to draw incorrectly, and as a minimum the size of the GUI would
     * need to be adjusted.
     */
    public static final int LEVEL_WIDTH = 36;

    /**
     * The height of the level, measured in tiles. Changing this may cause the
     * display to draw incorrectly, and as a minimum the size of the GUI would
     * need to be adjusted.
     */
    public static final int LEVEL_HEIGHT = 20;

    /**
     * A random number generator that can be used to include randomised choices
     * in the creation of levels, in choosing places to place the player and other
     * objects, and to randomise movement etc. Passing an integer (e.g. 123) to
     * the constructor called here will give fixed results - the same numbers
     * will be generated every time WHICH CAN BE VERY USEFUL FOR TESTING AND
     * BUGFIXING!
     */
    private Random rng = new Random();

    /**
     * The current turn number. Increased by one every turn. Used to control
     * effects that only occur on certain turn numbers.
     */
    private int turnNumber = 1;

    /**
     * The amount of money the player has in the current game. Money is gained by
     * harvesting crops.
     */
    private int money = 0;

    /**
     * The GUI associated with this GameEngine object. This link allows the
     * engine to pass level and entity information to the GUI to be drawn.
     */
    private GameGUI gui;

    /**
     * The 2 dimensional array of tiles that represent the current level. The
     * size of this array should use the LEVEL_WIDTH (X dimension!) and LEVEL_HEIGHT
     * (Y dimension!) attributes when it is created. This is the array that is used
     * to draw images to the screen by the GUI class, and by you to check what a specific
     * Tile contains by checking the content of specific elements of the array and
     * using the getType() method to determine the type of the Tile.
     * 
     * For example:
     * 
     * level[10][15].getType() == TiletType.DIRT
     * 
     * would return the value true if the tile at position 10,15 was a DIRT tile.
     */
    private Tile[][] level;
     
    /**
     * A Player object that is the current player. This object stores the state
     * information for the player, including the current position
     * (which is a pair of co-ordinates that corresponds to a tile in the
     * current level - see the Entity class for more information on the
     * co-ordinate system used as well as the coursework specification
     * document).
     */
    private Player player;

    /**
     * A Pest object used to create the pest when crops grow. The object
     * has position information stored via its attributes, and methods to check
     * and update the position of the pest.
     */
    private Pest pest;

    /**
     * An array of Entity objects that is used to store Tree and Rock objects for
     * one of the coursework tasks. New Tree and Rock objects should be created and
     * stored in this array for e.g. checking player movement as these objects
     * should block player movement into the tile that they are in.
     */
    private Entity[] debris;

    /**
     * Constructor that creates a GameEngine object and connects it with a
     * GameGUI object.
     *
     * @param gui The GameGUI object that this engine will pass information to
     * in order to draw levels and entities to the screen.
     */
    public GameEngine(GameGUI gui) {
        this.gui = gui;
    }

    /**
     * Creates a Player object in the game. This method should instantiate the
     * Player class by creating an object using the appropriate constructor. The
     * created object should then be assigned to the "player" attribute of this
     * class.
     *
     * This method should use fixed X and Y values for the player's position.
     */
    private void createPlayer() {
      for(int x = 0; x < LEVEL_WIDTH; x++){       // Scans all x-coordinates within the level
          for(int y = 0; y < LEVEL_HEIGHT; y++){   // Scan all y-coordinates within the level
             if(level[x][y].getType() == TileType.BED){    // uses current tile as the spawn location if it is a bed tile
                 player = new Player(x,y);       // Instantiate the player on the bed tile
             } 
          }
      }
    }
    
    /**
     * Handles the movement of the player when attempting to move in the game.
     * This method is automatically called by the GameInputHandler class when
     * the user has pressed one of the keys on the keyboard. Your code should
     * change the X and Y position of the player to place them in the correct tile
     * based on the direction of movement, i.e. changing their X or Y position by
     * +1 or -1. You will need to use the relevant method from the Player/Entity
     * classes to find the current position of the player, and set new values
     * for the X and Y position by using another method and passing it updated values.
     * @param direction the direction of movement based on the arrow key that was pressed:
     * 1 is up, 2 is right, 3 is down and 4 is left.
     */
    public void movePlayer(int direction) {
        int y = player.getY();  // gets position x
        int x = player.getX();  // gets position y
       switch (direction){ 
           
           case 4 -> x = x - 1; // enables the left movement
           case 2 -> x = x + 1; // enables the right movement
           case 3 -> y = y + 1; // enables the down movement
           case 1 -> y = y - 1; // enables the up movement  
           
       }
       player.setPosition(x, y); // sets new x and y positions 
       
     
     
    }

    /**
     * Generates a new level. This method should instantiate the level array, and
     * then fill it with Tile objects that are created inside this method.
     * This method is used for an early task, but later you will replace calls 
     * to this method with calls to generateBetterFarm() instead.
     * 
     * It is recommended that for this method you create the level array and then fill
     * it using for a pair of for loops, and create new Tile objects inside the inner loop.
     * Set their type using the constructor and the TileType enumeration, then
     * assign the Tile object to the current element in the array using the loop counters.
     * For this method you should use just Tile objects with the type STONE_GROUND.
     *
     */
    private void generateFarm() {
       level = new Tile[LEVEL_WIDTH][LEVEL_HEIGHT]; // sets new Tile array for width and height
        for(int x = 0; x < LEVEL_WIDTH; x++) {   
            for(int y = 0; y <LEVEL_HEIGHT; y++) {
                level[x][y] = new Tile(TileType.STONE_GROUND);
            }
        }
        
    }
    
    /**
     * This method is used in a later task to improve the movement logic for the player.
     * You should remove the line of code in this method and replace it with your own code.
     * You may like to start by copying and pasting your movement code from the movePlayer()
     * method and then editing it. This method should improve the movement code to prevent
     * the player from moving off the edge of the level (i.e. stopping movement that would
     * change the X or Y positions to be less than 0 or greater than the level width/height
     * values).
     * @param direction the direction of movement based on the arrow key that was pressed:
     * 1 is up, 2 is right, 3 is down and 4 is left.
     */
    public void betterMovePlayer(int direction) {
      
       int x = player.getX();
       int y = player.getY();
       
              
       
       switch (direction){  //creates the different directions 
           
           case 4 -> x = x - 1; // enables the left movement
           case 2 -> x = x + 1; // enables the right movement
           case 3 -> y = y + 1; // enables the down movement
           case 1 -> y = y - 1; // enables the up movement 
       }
          
       if (x < 0 || x >= LEVEL_WIDTH){       // position of player is not modified when player tries to go past width of level
          
           
       }
       else if(y < 0 || y >= LEVEL_HEIGHT){   
           
       }
       else if(level[x][y].getType() == TileType.HOE_BOX){
            
            player.setHeldItem(1);  // gives player blue flag when it tries to go through the hoebox 
       
       }    
       
       else if(level [x][y].getType() == TileType.SEED_BOX){
            player.setHeldItem(2);  //  gives the seed when it tries to go through the seedbox
            
        
       }
       else if( level[x][y].getType() == TileType.WALL) {
       }
       else{
           player.setPosition(x, y); // sets player's new position 
           
       }
       if(level [x][y].getType() == TileType.DIRT && player.getHeldItem() == 1){
            level[x][y] = new Tile(TileType.TILLED_DIRT); //creates tilled dirt when player goes through dirt 
        }
       
       if(level [x][y].getType() == TileType.TILLED_DIRT && player.getHeldItem() == 2){
            level[x][y] = new Tile(TileType.SOWED_DIRT); //creates tilled sowed dirt when player goes through dirt 
        }
       
           
       }
    
    
    /**
     * This method is used in a later task to generate a better level with more features.
     * Leave the generateFarm() method code as it is and write your new code in this method.
     * Remove the call to generateFarm() that is in this method and then 
     * begin writing your new code. You may wish to begin by copying and pasting the code
     * from generateFarm() into this method. 
     * 
     * This method should generate a farm with the same stone ground as before, but
     * should add a rectangular patch of dirt tiles somewhere in the level that will
     * be used with later tasks. For the highest marks in this task your dirt patch
     * should be dynamically placed i.e. its position and size is determined randomly
     * each time this method is called so it is different every time the game is started.
     */
    private void generateBetterFarm() {
        level = new Tile[LEVEL_WIDTH][LEVEL_HEIGHT]; // sets new Tile array for width and height
        for(int x = 0; x < LEVEL_WIDTH; x++) {  // creates loop 
            for(int y = 0; y <LEVEL_HEIGHT; y++) {
                level[x][y] = new Tile(TileType.STONE_GROUND);
            }
        }   
        int X = rng.nextInt(LEVEL_WIDTH - rng.nextInt(0, LEVEL_WIDTH));   // begins the dirt patch across the x-axis 
        int Y = rng.nextInt(LEVEL_HEIGHT - rng.nextInt(0,LEVEL_HEIGHT));  // begins the dirt patch across the y-axis 
        int dynamicX = rng.nextInt(X, LEVEL_WIDTH);   //  measures width of dirt patch
        int dynamicY = rng.nextInt(Y, LEVEL_HEIGHT);  // measures height of dirt patch
         for(int x = X; x < dynamicX; x++) {
             for ( int y = Y; y < dynamicY; y++){
                 level[x][y] = new Tile(TileType.DIRT);
             }
        
    }   
      level[rng.nextInt(0, LEVEL_WIDTH)] [rng.nextInt(0, LEVEL_HEIGHT)] = new Tile(TileType.HOE_BOX);   // creates the random generation of the hoe whenever game starts 
      
      
      level[rng.nextInt(0, LEVEL_WIDTH)] [rng.nextInt(0, LEVEL_HEIGHT)] = new Tile(TileType.SEED_BOX);  // creates the random generation of the seedbox whenever game starts 
      
      
} 
    
    
    
    
    /**
     * This method is used in an even later task to generate an even better level with even more features!
     * Leave the generateBetterFarm() method code as it is and write your new code in this method.
     * Remove the call to generateBetterFarm() that is in this method and then 
     * begin writing your new code.
     * You may wish to begin by copying and pasting the code from generateBetterFarm() into
     * this method. 
     * 
     * This method should generate the same farm as before with stone ground and a dirt patch,
     * but should also add a "farmhouse" using the farmhouse floor tiles and possibly wall tiles.
     * One bed should be placed somewhere in the house to be used in a later task. For top marks
     * in this task the farmhouse should be dynamically generated i.e. its size and/or position
     * is different each game, and ideally it should avoid overwriting the dirt patch previously created.
     */
    private void generateEvenBetterFarm() {
    level = new Tile[LEVEL_WIDTH][LEVEL_HEIGHT]; // sets new Tile array for width and height
        for(int x = 0; x < LEVEL_WIDTH; x++) {  // creates loop 
            for(int y = 0; y <LEVEL_HEIGHT; y++) {
                level[x][y] = new Tile(TileType.STONE_GROUND);
            }
        }   
        int X = rng.nextInt(LEVEL_WIDTH - rng.nextInt(0, LEVEL_WIDTH));   // begins the dirt patch across the x-axis 
        int Y = rng.nextInt(LEVEL_HEIGHT - rng.nextInt(0,LEVEL_HEIGHT));  // begins the dirt patch across the y-axis 
        int dynamicX = rng.nextInt(X, LEVEL_WIDTH);   //  measures width of dirt patch
        int dynamicY = rng.nextInt(Y, LEVEL_HEIGHT);  // measures height of dirt patch
         for(int x = X; x < dynamicX; x++) {
             for ( int y = Y; y < dynamicY; y++){
                 level[x][y] = new Tile(TileType.DIRT);
             }
         } 
      int houseX = rng.nextInt(LEVEL_WIDTH - rng.nextInt(0, LEVEL_WIDTH));   // begins the dirt patch across the x-axis 
        int houseY = rng.nextInt(LEVEL_HEIGHT - rng.nextInt(0,LEVEL_HEIGHT));  // begins the dirt patch across the y-axis 
        int housewidth = rng.nextInt(houseX, LEVEL_WIDTH);   //  measures width of dirt patch
        int househeight = rng.nextInt(houseY, LEVEL_HEIGHT);  // measures height of dirt patch       
        for(int x = houseX; x < housewidth; x++) {
             for ( int y = houseY; y < househeight; y++){
                 level[x][y] = new Tile(TileType.HOUSE_FLOOR);
             }
       
    }   
      level[rng.nextInt(0, LEVEL_WIDTH)] [rng.nextInt(0, LEVEL_HEIGHT)] = new Tile(TileType.HOE_BOX);   // creates the random generation of the hoe whenever game starts 
      
      
      level[rng.nextInt(0, LEVEL_WIDTH)] [rng.nextInt(0, LEVEL_HEIGHT)] = new Tile(TileType.SEED_BOX);  // creates the random generation of the seedbox whenever game starts 
      
      level[rng.nextInt(0, LEVEL_WIDTH)] [rng.nextInt(0, LEVEL_HEIGHT)] = new Tile(TileType.AXE_BOX);    // creates the random generation of the axe box whenever game starts 
      level[rng.nextInt(0, LEVEL_WIDTH)] [rng.nextInt(0, LEVEL_HEIGHT)] = new Tile(TileType.PICKAXE_BOX);    // creates the random generation of the pickaxe whenever game starts 
      
      
        for(int x = houseX; x < housewidth; x++) {
         level[x][houseY] = new Tile(TileType.WALL);   // creates top part of the wall around house 
         level [x] [househeight] = new Tile(TileType.WALL); // creates bottom part of the wall around house
        }
        for(int y = houseY; y <househeight; y++){   
            level[houseX][y] = new Tile(TileType.WALL); // creates the left side for the wall
            level[housewidth][y] = new Tile(TileType.WALL); // creates the right side of the wall 
        }
       level [housewidth][househeight] = new Tile(TileType.WALL); // ensures wall is all around house
        int openingX = rng.nextInt(houseX + 1, housewidth); 
        int openingY = houseY;                              
       level[openingX][openingY] = new Tile(TileType.HOUSE_FLOOR); // creates opening int the house
      level[rng.nextInt(houseX, housewidth)] [rng.nextInt(houseY, househeight)] = new Tile(TileType.BED); //creates bed inside the house 
      addDebris();
    }
    
    /**
     * This method is used to make the crops grow overnight if any tiles exist
     * that have been tilled with the hoe and then seeded with the seed bag.
     * You should check every tile in the level 2D array and any that are of the
     * SOWED_DIRT type should be changed to be of the CROP type. You can do this
     * by creating a new Tile object with the correct type and adding it to the
     * level array in the position of the current SOWED_DIRT tile being checked.
     * A later task will require you to modify this method so that a Pest is created
     * whenever one or more crops are created.
     */
    public void growCrops() {
       
        boolean growCrops = false;  // tracks whether at least one crop successfully grew this night
        // gooes through every tile in the level
        for(int x = 0; x <LEVEL_WIDTH; x++){
            for(int y = 0; y < LEVEL_HEIGHT; y++){
             if(level[x][y].getType() == TileType.SOWED_DIRT) {
                 if(rng.nextBoolean() == true) {  // randomly decides if the seeds grow or fail (true/false)
                     level[x][y] = new Tile(TileType.CROP);
                 growCrops = true;
                 }
                 else{      
                     level[x][y] = new Tile(TileType.TILLED_DIRT);  // seeds fail: go back to plain tilled dirt
                 }
            }
             else if(level[x][y].getType() == TileType.TILLED_DIRT){
                 
                 if(rng.nextBoolean() == true){  // random chance whether the tilled soil stays or degrades
                     
                 }
                 else {
                     level[x][y] = new Tile(TileType.DIRT); // false: tilled soil dries out and becomes normal dirt again
                 }
             }
        }
        }
        if(growCrops && pest == null){ // if one crop grew and there is no pest yet, create a pest
            createPest();
        }
    }
    
    
    
    /**
     * This method is used in an even later task to improve the movement logic for the player.
     * You should remove the line of code in this method and replace it with your own code.
     * You may like to start by copying and pasting your movement code from the betterMovePlayer()
     * method and then editing it. This method should add logic that handles the player moving into
     * a BED tile by calling the triggerNight() method. You should also rewrite the method to be
     * as efficient and easy to understand as possible, e.g by removing/refining duplicated code that is
     * common to all movement directions (or writing a new method or methods), creating new methods
     * that help streamline this code and any other improvements to readability and conciseness.
     * @param direction the direction of movement based on the arrow key that was pressed:
     * 1 is up, 2 is right, 3 is down and 4 is left.
     */
    public void evenBetterMovePlayer(int direction) {
       int x = player.getX();
       int y = player.getY();
       
              
       
       switch (direction){  //creates the different directions 
           
           case 4 -> x = x - 1; // enables the left movement
           case 2 -> x = x + 1; // enables the right movement
           case 3 -> y = y + 1; // enables the down movement
           case 1 -> y = y - 1; // enables the up movement 
       }
          
       if (x < 0 || x >= LEVEL_WIDTH){       // position of player is not modified when player tries to go past width of level
          
           
       }
       else if(y < 0 || y >= LEVEL_HEIGHT){   
           
       }
       else if(level[x][y].getType() == TileType.HOE_BOX){
            
            player.setHeldItem(1);  // gives player blue flag when it tries to go through the hoebox 
       
       }    
       
       else if(level [x][y].getType() == TileType.SEED_BOX){
            player.setHeldItem(2);  //  gives the seed when it tries to go through the seedbox
            
        
       }
       else if(level [x][y].getType() == TileType.AXE_BOX){
            player.setHeldItem(3);
            
       }
       else if(level [x][y].getType() == TileType.PICKAXE_BOX){
            player.setHeldItem(4);
            
       }
       else if( level[x][y].getType() == TileType.WALL) {
       }
       // variable to store any debris (tree or rock) that might block the player
       else {
           Entity debrisBlock = null;
           // index of that debris object inside the debris array
           int debrisIndex = -1; 
           // only check the debris array if it has been created 
           if(debris != null) {
               // loop through every debris object
               for(int g = 0; g < debris.length; g++) {
                   // make sure this entry is not null and is in the target tile (x, y)
                   if(debris[g] != null && debris[g].getX() == x && debris[g].getY() == y) {
                       debrisBlock = debris[g];
                       debrisIndex = g;
                   }
               }
           }
           if(debrisBlock != null) {
               if(debrisBlock instanceof Tree && player.getHeldItem() == 3) {
                   debris[debrisIndex] = null;
                   player.setPosition(x, y);
               }
               //  player holds the pickaxe if it's a rock,
               // breaks rock and allow movement into that tile
               else if(debrisBlock instanceof Rock && player.getHeldItem() == 4) {
                   debris[debrisIndex] = null;
                   player.setPosition(x, y);
           }
               // if the player does not have the right tool,
               // the tree or rock blocks the movement
               else {
                   
               }
           }
           // if no debris (tree/rock) is found at (x, y), move as normal
           else{
               player.setPosition(x, y);
           }
       }
       
       
       if(level [x][y].getType() == TileType.DIRT && player.getHeldItem() == 1){
            level[x][y] = new Tile(TileType.TILLED_DIRT); //creates tilled dirt when player goes through dirt 
        }
       
       if(level [x][y].getType() == TileType.TILLED_DIRT && player.getHeldItem() == 2){
            level[x][y] = new Tile(TileType.SOWED_DIRT); //creates tilled sowed dirt when player goes through dirt 
        }
       if (level[x][y].getType() == TileType.BED) { //checks if the tile the player is moving onto is a bed tile
        triggerNight();  // calls the triggerNight() method to start the night animation and handles crop growth after the player gets into bed  
}
       if(level[x][y].getType() == TileType.CROP){     // Check whether the tile at coordinates (x, y) currently contains a crop
         player.setPosition(x, y);    // Updates player's position to the crop tile to represent the harvesting action
         level[x][y] = new Tile(TileType.DIRT);    // Replace the harvested crop tile with a dirt tile to reflect the post-harvest state
         money = money + 5;     // Increase the player's in-game currency by the fixed harvest reward (5 units)
         System.out.println(money);   // Output the updated currency value to the console for monitoring and testing purposes
        
       } 
      if(pest != null && level[x][y] == level[pest.getX()][pest.getY()]) {   // Checks that a pest exists and that the player is on the same tile as the pest
         pest = null;     // Remove the pest when the player reaches its tile
     }
     
  }
    
    /**
     * Adds a pest to the current level. This method should create a new Pest object
     * and assign it to the pest attribute of this class. For top marks you should
     * make the position of the Pest dynamic i.e. it is randomly selected in some way.
     */
    private void createPest() {
      int pestX = rng.nextInt(LEVEL_WIDTH);  // chooses a random x position within the level width
      int pestY = rng.nextInt(LEVEL_HEIGHT); // chooses a random y position within the level height
      pest = new Pest(pestX,pestY);
    } 
    
    /**
     * Moves the pest object within the level. This method should change the pest objects
     * X and Y positions so that it moves towards the nearest crop in the level. You will
     * need to write code to find the nearest crop to the pest. You should then change the
     * pests position so that it moves closer to the nearest crop. The pest should not
     * be blocked by any tile types nor by Trees or Rocks (though you can add code to
     * create more complex movement rules if you wish!)
     */
    private void movePest() {
       // get the pest's current position
       int pestX = player.getX();  // retries  x position of pest 
       int pestY = player.getY();  // retrieves x position of pest
       if (pestX < 0 || pestX >= LEVEL_WIDTH){       // make sure the pest's position is still inside the level boundaries
           // do nothing if outside width
    }
       else if(pestY < 0 || pestY >= LEVEL_WIDTH) {     
           // do nothing if outside width
       }       
       
       else{
           pest.setPosition(pestX, pestY);
       }
        // variables to track the nearest crop 
       int dis_of_crop = Integer.MAX_VALUE;    // start with a very large distance
       int cropX = -1;                         // will hold x position of closest crop
       int cropY = -1;                         // will hold y position of closest crop

       // search the whole level to find the nearest crop tile
       for( int x = 0; x < LEVEL_WIDTH; x++) {
           for(int y = 0; y < LEVEL_HEIGHT; y++) {
               if(level [x][y].getType() == TileType.CROP) {    // check only crop tiles
                   int distance = Math.abs(cropX - pestX) + Math.abs(cropY - pestY);
                   if(distance <dis_of_crop) {  // if this crop is closer than the previous best, remember it
                     dis_of_crop = distance;
                     cropX = x;
                     cropY = y;
                   }
               }
           }
       }
       if(cropX > pestX) {  // move pest one step in x direction towards the closest crop
           pestX++;
       }
       else if (cropX < pestX) {
           pestX--;
       }
       else if(cropY > pestY) {  // move pest one step in y direction towards the closest crop
           pestY++;
       }
       else if(cropY < pestY) {
           pestY--;
       }
       if(level[pestX][pestY].getType() == TileType.CROP) { // if the pest moves into a crop tile, eat the crop (turn it back into dirt)   
           level[pestX][pestY] = new Tile(TileType.DIRT);
       }
       pest.setPosition(pestX, pestY);  //update the pest's position to the new coordinates
    }
 
    /**
     * This method should add debris to the game in the form of Tree and Rock objects.
     * It should instantiate the debris array with a sensible length and then fill
     * the array with instances of the Tree and Rock classes that you create in this
     * method. For top marks in this task the objects should be randomly placed so
     * that their position is different each game. Ideally they should not be placed
     * in a way that prevents the player from playing the game (e.g. should not be placed
     * in a way that blocks the door to the farmhouse!)
     * Rocks and Trees should block player movement; add code to your newest
     * player movement method (depends on which tasks you have already completed!)
     */
    private void addDebris() {
        
       int  numDebris = rng.nextInt(6,15);  // Generate a random number of debris entities in the range [6, 15)
       debris = new Entity[numDebris];     // Allocate an array to store references to all debris entities
       
       
       for (int i = 0; i < numDebris; i++) {     
           
           int x = rng.nextInt(0,LEVEL_WIDTH);      // Randomly select an x-coordinate within the horizontal bounds of the level
           int y = rng.nextInt(0,LEVEL_HEIGHT);    // Randomly select a y-coordinate within the vertical bounds of the level
        
        if(level[x][y].getType() == TileType.STONE_GROUND) {   // Only place debris on tiles that are classified as stone ground
            if (i % 2 == 0) {             // Use the loop index parity to alternate between rock and tree instances
                debris[i] = new Rock(x,y);
                
            }
            else{
                debris[i] = new Tree(x,y);       // Create a tree entity at the chosen coordinates
            }
            
        }
       }
    }

    /**
     * A method to trigger the night animation for the game when the player enters
     * a BED tile. You can call this method to start the night animation and the growth
     * of crops.
     */
    private void triggerNight() {
        gui.doNight(this);
    }
    
    /**
     * A method that is used to prevent player movement during the night animation.
     * @return true if the night animation is still playing, false otherwise.
     */
    public boolean sleeping() {
        return gui.animatingNight();
    }

    /**
     * Performs a single turn of the game when the user presses a key on the
     * keyboard. The method increments the turnNumber, moves the pest object
     * every four turns, and requests the GUI to redraw the game level by passing
     * it the level, debris, player and pest objects/arrays.
     *
     */
    public void doTurn() {
        turnNumber++;
        if (turnNumber % 4 == 0 && pest != null) {
            movePest();
        }
        gui.updateDisplay(level, debris, player, pest);
    }

    /**
     * Starts a game. This method generates a room, adds the dropper and player,
     * then requests the GUI to update the level on screen using the information
     * passed to it.
     */
    public void startGame() {
        generateEvenBetterFarm();
        createPlayer();
        gui.updateDisplay(level, debris, player, pest);
    }
}
